#!/bin/bash

export ip=`ifconfig eth0|grep "inet"|awk -F" " '{print $2}'|awk '{print $1}'`

#echo $ip
export date=`date "+%Y-%m-%d %H:%M:%S"`

echo "$date start push data" 

# push node_exporter
curl -s 172.18.223.145:9100/metrics | curl --data-binary @- http://localhost:9091/metrics/job/node-exporter/ipaddr/172.18.223.145
curl -s 172.18.223.146:9100/metrics | curl --data-binary @- http://localhost:9091/metrics/job/node-exporter/ipaddr/172.18.223.146
curl -s 172.18.223.147:9100/metrics | curl --data-binary @- http://localhost:9091/metrics/job/node-exporter/ipaddr/172.18.223.147
curl -s 172.18.85.248:9100/metrics | curl --data-binary @- http://localhost:9091/metrics/job/node-exporter/ipaddr/172.18.85.248

## postgresql、redis、rabbitmq exporter
curl -s localhost:9121/metrics|curl --data-binary @- http://localhost:9091/metrics/job/redis-exporter/ipaddr/172.18.223.146
curl -s localhost:9419/metrics|curl --data-binary @- http://localhost:9091/metrics/job/rabbitmq-exporter/ipaddr/172.18.223.146
curl -s localhost:9187/metrics|curl --data-binary @- http://localhost:9091/metrics/job/postgres-exporter/ipaddr/172.18.223.147

### blackbox tcp_telnet 
curl -s "localhost:9115/probe?target=172.18.223.146:6379&module=tcp_connect"|curl --data-binary @- http://localhost:9091/metrics/job/blackbox-exporter/app/redis/ipaddr/172.18.223.146
curl -s "localhost:9115/probe?target=172.18.223.147:25432&module=tcp_connect"|curl --data-binary @- http://localhost:9091/metrics/job/blackbox-exporter/app/postgresql/ipaddr/172.18.223.147
curl -s "localhost:9115/probe?target=172.18.223.146:15672&module=tcp_connect"|curl --data-binary @- http://localhost:9091/metrics/job/blackbox-exporter/app/rabbitmq/ipaddr/172.18.223.146
curl -s "localhost:9115/probe?target=172.18.223.145:8088&module=tcp_connect"|curl --data-binary @- http://localhost:9091/metrics/job/blackbox-exporter/app/tomcat/ipaddr/172.18.223.145
curl -s "localhost:9115/probe?target=172.18.85.248:8090&module=tcp_connect"|curl --data-binary @- http://localhost:9091/metrics/job/blackbox-exporter/app/tomcat/ipaddr/172.18.85.248
curl -s "localhost:9115/probe?target=172.18.223.145:8090&module=tcp_connect"|curl --data-binary @- http://localhost:9091/metrics/job/blackbox-exporter/app/nginx/ipaddr/172.18.223.145

